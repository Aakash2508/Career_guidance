import React, { useState } from 'react';
import { Container, Form, Button, OverlayTrigger, Popover, Tooltip } from 'react-bootstrap';

const RoadmapGenerator = () => {
  const [current, setCurrent] = useState('');
  const [desired, setDesired] = useState('');
  const [roadmap, setRoadmap] = useState([]);

  const handleGenerate = async () => {
    try {
      const response = await fetch('http://localhost:5007/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ current, desired }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText);
      }

      const data = await response.json();
      setRoadmap(data.roadmap || []);
    } catch (err) {
      console.error('Error generating roadmap:', err.message);
      alert('Error: ' + err.message);
    }
  };

  return (
    <Container className="py-5">
      <h2 className="mb-4 text-center">🌟 Career Roadmap Generator</h2>

      <Form className="mb-5">
        <Form.Group>
          <Form.Label>Current Status</Form.Label>
          <Form.Control
            placeholder="e.g., High School Student"
            value={current}
            onChange={(e) => setCurrent(e.target.value)}
          />
        </Form.Group>

        <Form.Group className="mt-3">
          <Form.Label>Desired Role or Goal</Form.Label>
          <Form.Control
            placeholder="e.g., Data Scientist"
            value={desired}
            onChange={(e) => setDesired(e.target.value)}
          />
        </Form.Group>

        <Button variant="primary" className="mt-3" onClick={handleGenerate}>
          Generate Roadmap
        </Button>
      </Form>

      {roadmap.length > 0 && (
        <div className="d-flex justify-content-center overflow-auto">
          <svg width="600" height={roadmap.length * 120}>
            {roadmap.map((item, index) => {
              const y = index * 120 + 60;
              return (
                <g key={index}>
                  {/* Connecting line */}
                  {index > 0 && (
                    <line
                      x1={150}
                      y1={y - 120}
                      x2={150}
                      y2={y}
                      stroke="#888"
                      strokeWidth="2"
                    />
                  )}

                  {/* Circle node */}
                  <circle cx={150} cy={y} r={25} fill="#007bff" />

                  {/* Step label with tooltip */}
                  <OverlayTrigger
                    placement="right"
                    overlay={
                      <Tooltip id={`tooltip-${index}`}>
                        {item.description}
                      </Tooltip>
                    }
                  >
                    <text
                      x={190}
                      y={y + 5}
                      fontSize="16"
                      fill="#333"
                      style={{ cursor: 'pointer' }}
                    >
                      {item.step}
                    </text>
                  </OverlayTrigger>

                  {/* Popover on click */}
                  <OverlayTrigger
                    trigger="click"
                    placement="right"
                    overlay={
                      <Popover>
                        <Popover.Header as="h3">{item.step}</Popover.Header>
                        <Popover.Body>{item.description}</Popover.Body>
                      </Popover>
                    }
                  >
                    <circle
                      cx={150}
                      cy={y}
                      r={25}
                      fill="transparent"
                      style={{ cursor: 'pointer' }}
                    />
                  </OverlayTrigger>
                </g>
              );
            })}
          </svg>
        </div>
      )}
    </Container>
  );
};

export default RoadmapGenerator;
